import React from "react"

export default class InputBusca extends React.Component {
  constructor () {
    super()
  }
  render() {
    return (
      <div>
        <label>Insira um CEP e veja mais dados relacionados.</label>
        <br/>
        <input type="text"/>
      </div>
    )
  }
}