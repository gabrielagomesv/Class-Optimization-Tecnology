import React from "react"
import InputBusca from "./input_busca"
import Header from "./header"
import InputNome from "./input_nome"
//import Usuario from "./usuario"

export default class App extends React.Component {
	constructor () {
		super()

	}

	render () {
		return (
			<div className="container">
				<Header></Header>
				<InputNome></InputNome>
				<InputBusca>Buscar por:</InputBusca>
				<Usuario></Usuario>
			</div>
		)
	}
}