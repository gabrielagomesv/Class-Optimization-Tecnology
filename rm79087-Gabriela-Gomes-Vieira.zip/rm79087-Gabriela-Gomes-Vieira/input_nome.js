import React from "react";

export default class InputNome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {value: ''};

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({value: event.target.value});
  }

  handleSubmit(event) {
    alert('Você não é mais um estranho! Seu nome foi salvo para esta sessão, ' + this.state.value);
    event.preventDefault();
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <label>Insira seu nome: </label>
          <input type="text" value={this.state.value} onChange={this.handleChange} required/>&nbsp;
          <input type="submit" value="Salvar" />
          <br/>
          <br/>
        </form>
        <h4>Sessão atual de {this.state.value}</h4>
      </div>
    );
  }
}
