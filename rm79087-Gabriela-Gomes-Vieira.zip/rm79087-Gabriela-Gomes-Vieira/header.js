import React from "react"

export default class InputNome extends React.Component {
  constructor () {
    super()
  }
  render() {
    return (
      <header>
        <center>
          <h1>Olá, seja bem vindo :)</h1>
          <p>Faça sua busca no campo abaixo.</p>
          </center>
      </header>
    )
  }
}