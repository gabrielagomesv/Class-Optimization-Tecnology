import React from "react"

export default class Usuario extends React.Component {
  constructor(props) {
    super(props);
    this.state = { usuario: [] }
  }

  componentDidMount() {
    fetch('https://randomuser.me/api/?results=10')
    .then(response => response.json())
    .then((data) => { this.setState({ usuario: data }) })
  }

  render(){
    return(
      <div>
        {this.state.cep}
      </div>
    )
  }
}